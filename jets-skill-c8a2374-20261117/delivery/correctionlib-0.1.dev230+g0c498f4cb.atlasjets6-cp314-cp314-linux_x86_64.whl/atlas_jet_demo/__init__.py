"""Packaged ATLAS jet correction inputs and runtime."""
