#ifndef CORRECTIONLIB_VERSION_H
#define CORRECTIONLIB_VERSION_H

#include <string_view>

namespace correction {
  constexpr std::string_view correctionlib_plugin_build_id{"e10cf3184151c3dc2f92fb045edbe430469c78029fbc48eef97239df7b882b31:08534a532a33e49965b9f62e51260712dad0f68b8a3577dc5b55be43266a6825"};
	constexpr std::string_view correctionlib_version{"0.1"};
	constexpr int correctionlib_major_version{0};
	constexpr int correctionlib_minor_version{1};
}

#endif // CORRECTIONLIB_VERSION_H
